# Ejercicio 1
# Escriba una funciòn que reciba un nùmero entero y 
# y retorne dos listas, una con los dìgitos entre 0 y 4
# y otra con los dìgitos entre 5 y 9

def lista_split(num):
    if isinstance(num,int) : 
        return lista_split_aux(num,[],[])
    else:
        print("El nùmero debe ser entero")

def lista_split_aux(num,lista0a4,lista5a9):
    if num == 0 :
        return lista0a4 , lista5a9
    else:
        digito = num%10
    
        if (digito<= 4):
            lista0a4.append(digito)
        else:
            lista5a9.append(digito)
        
        return lista_split_aux(num//10, lista0a4,lista5a9)

# print(lista_split(1023456789))

# ___________________________________________________________________________________________________________________________________________________
# 2. Construya una funci´on de nombre split(lista). Esta funci´on toma una lista y la divide
# en sublistas usando como punto de corte cada vez que aparezca un cero.


# Ejercicio 3 
# Escriba una funci´on cambie todos(num) que reciba una n´umero entero y sustituya
# todos los valores que aparezcan 2 o mas veces por un cero


# Ejercicio 4


# 5 Escriba una funci ́on recursivadivida(dig, num) que reciba un d ́ıgito 
# y un n ́umero enteroy obtenga dos n ́umeros, el primero compuesto por los 
# dıgitos mayores o iguales al d ́ıgitodado y el segundo compuesto por 
# los d ́ıgitos menores al d ́ıgito dado.

def mayores_menores(num,dig):
    if isinstance(num,int) and dig in range(0,10) :
        return mayores(num,dig,0,0) , menores(num,dig,0,0)
    else:
        return "ERROR"

def mayores(num,dig,potencia,resultado):
    if num == 0 :
        return resultado
    else:
        digito = num%10
        if digito>= dig :
            resultado =resultado + digito*10**potencia
            return mayores(num//10,dig,potencia+1,resultado)
        else:
            return mayores(num//10, dig,potencia,resultado)

def menores(num,dig,potencia,resultado):
    if num == 0 :
        return resultado
    else:
        digito = num%10
        if digito< dig :
            resultado = resultado + digito*10**potencia
            return menores(num//10,dig,potencia+1,resultado)
        else:
            return menores(num//10, dig,potencia,resultado)

print(mayores_menores(12345678,4))

# _____________________________________________________________________________________________________________________________________
# Ejercicio 6
# Utilice recursividad de cola para implementar la siguiente sumatoria.
# Como funciòn debe recibir como parámetro un número que funcione como 
# límite superior(max_value)
def sumatoria(max_value):
    return sumatoria_aux(max_value,0)

def sumatoria_aux(max_value, resultado):
    if max_value == 0:
        return resultado
    else:
        resultado += 2*max_value**3 + 3*max_value**2 +1
        return sumatoria_aux(max_value -1,resultado)

# print(sumatoria(5))




# def split_aux(lista,resultado):
    # if lista == [] :
        # return resultado
    # else:
        # if 0 in lista :
            # resultado=resultado + lista[0:lista.index(0)]
            # del lista[0:lista.index(0)+1]
            # return split_aux(lista,resultado)
        # else:
            # return lista
# print(split_aux([1,2,3,0,4,5,6,0,7,8,9,0,6,5,4], 0))