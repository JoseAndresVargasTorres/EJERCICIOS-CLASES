#1. Un cuadro semi-magico es una matriz m xn en la cual todas las filas que la component suman
#lo mismo. Por ejemplo, la matriz [[6,2,1], 5,4,0], [4,4,1]] seria un cuadro semimagico. Escriba
#una funcion recursive semi (matriz) que reciba una matriz y verifique si el argumento dado
#es o no un cuadro semi-magico

#Ejemplo:
#semi ( [ [6, 2, 1] , [5, 4, 0] , [4,4,1]])
#> > > True
#semi ( [ [6, 7, 1] , [13, 1, 0]])
#>> > True
"""
def matriz_semi_magica(matriz):
    if isinstance(matriz[0] == list):
        return matriz_aux(matriz,0,[])
    else:
        return "Error"

def matriz_aux(matriz,i,lista_suma):
    if matriz == []:
        return lista_suma
    else:
        if i <len(matriz[0]):
            lista_suma+= matriz[0][i]
            return matriz_aux(matriz,i+1,lista_suma)
        else:
"""

#(5,1029099)
#9,1020
#Escriba una función recursiva divida(dig,num) que reciba un dígito y un
# número entero y obtenga dos números, el primero compuesto por los dígitos
#mayores o iguales al dígito dado y el segundo compuesot por los dígitos menores
#al dígito dado. La función debe comportarse como los siguientes ejemplos


def divida(dig,num):
    if isinstance(num,int) and dig in range(0,10):
        return divida_aux(dig,num,0,0,0)
    else:
        return ERROR

def divida_aux(dig,num,i,mayores,menores) :
    if num == 0 :
        return (mayores , menores)
    else:
        digito_num = num % 10
        if digito_num >= dig :
            mayores += (digito_num) * (10**i)
            return divida_aux(dig,num//10,i+1,mayores,menores)
        else:
            if digito_num < dig :
                menores += (digito_num) * (10**i)
                return divida_aux(dig, num//10, i + 1, mayores, menores)

def numeros_mayores(dig,num,i,mayores):
    if num == 0 :
        return mayores
    else:
        digito_num = num % 10
        if digito_num >= dig :
            mayores += (digito_num) * (10**i)
            return divida_aux(dig,num//10,i+1,mayores)

print(divida(5,1029099))




