#matriz = [ [6, 2, 1] , [5, 4, 0] , [4,4,1],[3,2,1]]
#print(len(matriz))
#print(len(matriz[0]))
#con while
#lineas = 4
#n = lineas
#for i in range(n + 1):
#    espacios = n-i
#    print(" " * espacios + "* " * i)

   # def frecuencias(lista):
    #    if isinstance(lista,list):
      #     return frecuencias_lista_aux(lista,0,[])
    #    else:
    #        return "ERROR"

#    def frecuencias_lista_aux(lista,i,resultadp)
#
#    def Contar(lista, ele, contador):
#        if lista == []:
#
 #           return contador

#        elif lista[0] == ele:

 #           contador += 1
 #           return Contar(lista[1:], ele, contador)

 #       else:
 #           return Contar(lista[1:], ele, contador)
""""
num = 12345
digito = num % 10

lista = []
lista += [digito]

print(lista)

def contar_repetidos(num,dig,cont):
    if num == 0 :
        return cont
    else:
        digito_a_comparar = num % 10
        if digito_a_comparar == dig:
            return contar_repetidos(num//10,dig,cont+1)
        else:
            return contar_repetidos(num//10,dig,cont)


def matriz_semi_magica(matriz):
    #para verificar que sea una matriz
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return matriz_aux(matriz,0)
    else:
        return "ERROR"

print(matriz_semi_magica([[6,2,1], [5,4,0], [4,4,1]]))


def cambie_todos(num):
    if isinstance(num,int) and num>=0 :
        num_str = str(num)
        size = len(num_str)
        return cambie_todos_aux(num_str, 0, size)
    else:
        "ERROR"

def cambie_todos_aux(num, index, size):
    if(index >= size):
        return num

    digito = num[index]

    if(num.count(digito) >= 2):
        num = num.replace(digito, "0")

    return cambie_todos_aux(num, index + 1, size)

print(cambie_todos(13365439925))

matriz = [ [2, 3], [4, 5]]

print(matriz[0][0])


palabra= "hola"

stringer = ""
stringer = palabra[0]
print(palabra)
]print(stringer)
"""
""""
matriz = [[1,2,3,4,5], [6,7,8,9, 10]]

matriz1_2 = matriz[0] + matriz[1]

print(matriz1_2)

    if idx > len(lista)-1:
        return num_repetidos
    else:
        if isinstance(lista[idx],int):
            if lista[idx] == num :
                num_repetidos += 1
                return repetidos_aux(lista,num,idx+1,num_repetidos)
            else:
                return repetidos_aux(lista, num, idx + 1, num_repetidos)
        else:
            if isinstance(lista[idx],list):
                repetidos_aux(lista[idx],num,0,num_repetidos)
                return repetidos_aux(lista,num,idx+1,num_repetidos)
            else:
                return "ERROR"

print(repetidos([0,1,[2,3,4],0,2] , 0))
print(repetidos([0,1,[2,3,4],0,2],4))

def repetidos(lista, num):
    if isinstance(lista,list) and isinstance(num,int):
        return repetidos_aux(lista,num,0,0)
    else:
        return "ERROR"

def repetidos_aux(lista,num,idx,num_repetidos):
    if idx == len(lista):
        return num_repetidos
    else:
        if isinstance(lista[idx],int):
            if lista[idx] == num :
                num_repetidos += 1
                return repetidos_aux(lista,num,idx+1,num_repetidos)
            else:
                return repetidos_aux(lista,num,idx+1,num_repetidos)
        else:
            if isinstance(lista[idx],list):
                contar_listas(lista[idx],num,0,0)
                return repetidos_aux(lista,num,idx+1,num_repetidos)
def contar_listas(lista,num,idx,contador):
    if idx == len(lista):
        return contador
    else:
        if isinstance(lista[idx],int):
            if lista[idx] == num:
                contador += 1
                return contar_listas(lista,num,idx+1,contador)
            else:
                if isinstance(lista[idx],list):
                    contar_listas(lista[idx],num,0,contador)
                    return contar_listas(lista,num,idx+1,contador)
                else:
                    return "ERROR"

print(repetidos([0,1, [2,3,4],0,2], 0))
print(repetidos( [0,1, [2, [3],4],0,2], 4))
"""


matriz = [[-2, 1, 2, 4], [9, 8, -4, -3], [5, -8, 3, 2]]
for fila in matriz:
    print(fila)
    for columna in fila:
        print(columna)

"""lista_resultado= []
    suma = ""
    idx = 0
    num_string = str(num)
    while idx < len(num_string):


        if num_string[idx] == "0":
            lista_resultado += [num_string[0:idx+1]]
            idx += 1
            num_string = num_string[idx:-1]
        else:
            idx += 1
            num_string = num_string[idx:-1]


    return lista_resultado

"""