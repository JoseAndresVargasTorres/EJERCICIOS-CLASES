#
#                           José Andrés Vargas Torres
#                               Examen parcial II
#
#1

def frecuencias(lista):
    if isinstance(lista,list):
       return frecuencias_lista(lista,0,[])
    else:
        return "ERROR"

def frecuencias_lista(lista,dig,lista_nueva):
    if dig <= max(lista):
        lista_nueva += [lista.count(dig)]
        return frecuencias_lista(lista,dig+1,lista_nueva)
    else:
        return lista_nueva
#print(frecuencias([1, 1, 2, 1, 4]))

#2
def bordes(matriz):
    num = 0
    for fila in range(0,len(matriz)):

        for columna in range(0,len(matriz[fila])):
            if fila == 0 :

                num += matriz[fila][columna]

            elif fila == len(matriz) -1 :
                    num += matriz[fila][columna]
            elif columna == 0 or columna == len(matriz):
                num += matriz[fila][columna]
    return num




#print(bordes([[1,2,3,4,5], [6,7,8,9, 10], [11,12,13,14,15], [16,17,18,19,20]]))

#3
def cambia(num):
    if isinstance(num,int):
        return cambia_aux(num,0,0)
    else:
        return "ERROR"

def cambia_aux(num,potencia,resultado):
    if num == 0:
        return resultado
    else:
        digito = num % 10
        if digito % 4 != 0:
            resultado += digito*10**potencia
            return cambia_aux(num//10,potencia+1,resultado)
        else:
            return cambia_aux(num//10, potencia+1,resultado)
#print(cambia(1488))




#4


def triangulo(lineas):
    n = lineas
    for i in range(n,-1,-2):

        espacios = n-i

        print(" "*espacios+"* "*i)

#triangulo(7)



