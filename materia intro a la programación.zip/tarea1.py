#1. Determine la raiz recibiendo los valores de indice y radicando. Aplique restricciones

def calculo_raices(indice,radicando):
      if (indice%2 == 0 and radicando<0):
            print("No existe solución real")
      else: 
            resultado=radicando**(1/indice)
            print("El resultado de la operación es {} ".format(resultado))


calculo_raices(2,-25)
calculo_raices(2,4)

#2Escriba una función en Python que calcule e imprima el promedio de tres números recibidos como argumentos

def calculo__promedio(n_1,n_2,n_3):
      promedio=(n_1 + n_2 +n_3)/3
      print("El promedio de los tres numeros es {} ".format(promedio))

calculo__promedio(5,7,10)
calculo__promedio(3,3,3)




#3. Escriba una función que determine si un número es múltiplo de otro
def multiplo(num_1,num_2):
  if (num_1%num_2 == 0)     :
      print("El numero {} es multiplo de {} ".format(num_2,num_1))
  else: 
      print("El numero {} NO es  multiplo de {}".format(num_2,num_1))


multiplo(10,5)
multiplo(10,3)


#4Escriba una función que permita calcular el área de un rectángulo y de un triángulo.
#debe recibir como parámetros la base, la altura y la figura a la que le va a calcular el
#área (rectángulo o triángulo).
def calcular_areas(base, altura, figura):
      if(figura == "triangulo"):
            area = base* altura / 2 
            print("El area de la figura {} es {}".format(figura, area))
      elif(figura == "rectangulo"):
            area = base * altura
            print("El area de la figura {} es {}".format(figura, area))
      else: 
            print("la figura {} no reconocida". format(figura))
            #Imprimir el resultado
      

calcular_areas(10,15, "triangulo")
calcular_areas(10,15,"rectangulo")
calcular_areas(12,13,"rombo")


#5Escriba una función que permita verificar si una palabra es palíndromo o no.
def resolv_palindromo(palabra):
      palabra = palabra.lower()
      largo_cadena = len(palabra)
      if largo_cadena % 2 ==0 :
            izquierda = palabra [:largo_cadena //2 ]
            derecha = palabra [ largo_cadena //2: ]
      else:
            izquierda = palabra [:largo_cadena //2 :]
            derecha = palabra [ largo_cadena //2+1 :]
      
      return izquierda == derecha [::-1 ]
       
print(resolv_palindromo("alfajor"))
print(resolv_palindromo("reconocer"))   

#6. Escriba una función que permita convertir de km/h a mph (millas por hora).
def conversion_1(km):
      millas = km * 1/1.609
      print("La conversion de {}km/h a millas/h equivale a {}millas/h".format(km,millas))

conversion_1(36)


#7 Escriba una función que permita calcular multas de tránsito por exceso de velocidad,
#de acuerdo a las siguientes reglas:
#○ Tendrá una multa de 100 000 si excede por más de 10km/h la velocidad
#máxima.
#○ La multa será de 200 000 si excede por más de 20km/h la velocidad máxima.
#○ Tendrá una multa de 300 000 si excede por más de 30km/h la velocidad
#máxima
def multa_transito(v_conductor,v_maxima):
      if (10<v_conductor-v_maxima<=20):
            print("El conductor debera pagar una multa de 100000")
      elif(20<v_conductor-v_maxima<=30):
            print("El conductor debera pagar una multa de 200000")
      elif(v_conductor-v_maxima>30):
            print("El conductor debera pagar una multa de 300000")
      else:
            print("El conductor no debera pagar ninguna multa")

multa_transito(108,90)
multa_transito(45,18)
multa_transito(430,30)

#8Hacer una función que reciba un número de exactamente 5 dígitos y los sume
def suma_digitos(num):
      digito_5 = num % 10
      num = num // 10
      digito_4 = num % 10
      num = num // 10
      digito_3 = num % 10
      num = num // 10
      digito_2 = num % 10
      num = num // 10
      digito_1 =num
      
      total =digito_1+digito_2+digito_3+digito_4+digito_5
      print("El resultado final de los digitos de los 5 numeros es {}".format(total))
      


suma_digitos(12345)