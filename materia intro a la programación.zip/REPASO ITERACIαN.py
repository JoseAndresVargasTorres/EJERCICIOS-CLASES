#Recorrer una lista y cambiar aquellos valores en la lista que se repitan dos o más veces por un cero

def cambiar_lista(lista):

    lista_sin_repetidos = []
    for i in lista:
        if repetidos(lista[i],lista,0) > 1:
            lista_sin_repetidos += [0]
        else:
            lista_sin_repetidos += [lista[i]]
    return lista_sin_repetidos

def repetidos(digito,lista,contador):
    for i in lista:
        if lista[i] == digito:
            contador += 1
    return contador

#print(cambiar_lista([1,1,2,3,4,2,5,6]))


#7. Escriba una funcion iterative elimine_todos (ele, lista) que reciba un
#elemento y una lista y elimine todas las apariciones del elemento en la lista

#>>> elimine_todos (4, [4, 5, 3, 4, 5, 3, 4,8])
#(5, 3, 5, 3, 8]
lista = [4, 5, 3, 4, 5, 3, 4,8]
def elimine_todos(ele,lista):
    idx = 0
    largo = len(lista)
    lista_resultado = []

    while idx < largo :
        if ele != lista[idx]:
            lista_resultado += [lista[idx]]
        idx += 1
    return lista_resultado

#print(elimine_todos(4,lista))


#Escriba una funcion recursive negativos (matriz) que reciba una matriz de
#tamano mxn y devuelve una tupla con las posiciones de la matriz (fila, columna) que

#contienen numeros negativos.
#> >> negativos ( [[-2, 1, 2, 4], [9, 8, -4, -3], [5, -8, 3, 2]])
#[[0, 0], [1, 2], [1, 3], [2, 1]]

def negativos(matriz):

    lista_posiciones = []
    #if isinstance(matriz[0],list) and isinstance(matriz,list):
    for fila in range(0,len(matriz)):
         for columna in range(0,len(matriz[fila])) :
             if matriz[fila][columna] < 0 :
                lista_posiciones += [[fila,columna]]
    return lista_posiciones
            #for columna in fila[0]


#print(negativos([[-2, 1, -2, 4], [9, 8, -4, -3], [5, -8, 3, 2]]))


#Escriba una funcion iterative llamada partir (num) que reciba un numero entero y
#produce una lista de numeros, donde cada numero se forma con los digitos hasta
#encontrar la aparicion de ceros, es decir, el cero va a ser el punto de corte para formar
#los numeros#>>> partir (123029201034)
                #[123, 292, 1, 34]
                #>>> partir (120)          #[12]

#>>> partir (89762931)
#89762931

def partir(num):
    lista_resultado = []
    string_2 = ""
    num_string = str(num)

    for i in range(0,len(num_string)):

        if num_string[i] != "0":
            string_2 += num_string[i]
        else:
            lista_resultado += [int(string_2)]
            string_2 = ""


    return lista_resultado + [int(string_2)]


#print(partir(1230456078))
#print(partir(12345678))



#Escriba una función iterativa utilizando el estatuto for-in
#que imprima los números del 1 al 100 en líneas de 10 números y que cuando llegue a
#100 escriba "Fin del programa"

#def imprimir():
 #   for i in range(0,100):
 #       for j in range (i,i+10):
 #           print(j)

#imprimir()

#Escriba una función iterativa utilizando el estatuto
#for-in que reciba un número y calcula el factorial de este
def factorial(num):
    resultado = 1
    #La función para cuando el último número
    #es igual al número dado
    for i in range(1,num+1):
        resultado *= i
    return resultado
#print(factorial(4))

#Escribir una funcion iterative utilizando el estatuto while
# que reciba dos numeros enteros como parametros e
#imprima todos los numero primos entre ellos.

def pares(lim_inferior,limite_superior):
    lista_pares = []
    for i in range(lim_inferior,limite_superior+1):
        if i < 2 :
            pass
        elif definir_pares(i):
            lista_pares += [i]
    return lista_pares


def definir_pares(num):
    for idx in range(2, num):
        if num % idx == 0:
            return False
    return True
""""
#para impares
def definir_pares(num):
    for idx in range(2,num):
        if num % idx == 0 :
            return True
    return False

"""

#print(pares(3,29))


#Disene un programa utilizando el estatuto while que imprima los numeros
# del I al 100 en lineas de 10 numeros y
#que cuando llegue a 100 escriba: "Fin del programa".
def imprima():
    for i in range(1,100,10):
        for j in range(i, i+10):
            print(j, end="\t")#Esto para que los números vayan hacia los lados
        print("\n")     #imprimir salto de línea

#imprima()
#\n para mover de la primera línea a la segunda
#\t para mover un espacio más en la misma línea

#Función que haga tablas de multiplicar
# Escriba
def multiplica(a, b):

    i = 1

    # Ciclo exterior
    while i <= a:
        j = 1
        # Ciclo interior
        while j <= b:

            print (i * j, "\t", end="")
            j += 1
        print ("\n")
        i += 1
#multiplica (5, 5)
