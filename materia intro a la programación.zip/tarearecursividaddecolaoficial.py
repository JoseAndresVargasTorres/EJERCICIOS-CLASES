# Ejercicio 1
# Escriba una funciòn que reciba un nùmero entero y 
# y retorne dos listas, una con los dìgitos entre 0 y 4
# y otra con los dìgitos entre 5 y 9

def lista_split(num):
    if isinstance(num,int) : 
        return lista_split_aux(num,[],[])
    else:
        print("El nùmero debe ser entero")

def lista_split_aux(num,lista0a4,lista5a9):
    if num == 0 :
        return lista0a4 , lista5a9
    else:
        digito = num%10
    
        if (digito<= 4):
            lista0a4.append(digito)
        else:
            lista5a9.append(digito)
        
        return lista_split_aux(num//10, lista0a4,lista5a9)

# print(lista_split(1023456789))


# 2. Construya una función de nombre split(lista). Esta función toma una lista y 
# la divide en sublistas usando como punto de corte cada vez que aparezca un cero.
def split(lista):
    return split_aux(lista, [], [])

def split_aux(lista, sublista, result):
    if lista == []:
        result = result + [sublista]
        return result
    else:
        if lista[0]==0:
            result = result + [sublista]
            sublista = []
        
        else:
            sublista = sublista + [lista[0]]

        return split_aux(lista[1:], sublista, result)
    
# print(split([1,2,3,4,0,5,6,7,0,8,9]))


# Ejercicio 3 
# Escriba una funci´on cambie todos(num) que reciba una n´umero entero y sustituya
# todos los valores que aparezcan 2 o mas veces por un cero

def cambie_todos(num):
    if isinstance(num,int) and num>=0 :
        num_str = str(num)
        size = len(num_str)
        return cambie_todos_aux(num_str, 0, size)
    else:
        "ERROR"

def cambie_todos_aux(num, index, size):
    if(index >= size):
        return num

    digito = num[index]

    if(num.count(digito) >= 2):
        num = num.replace(digito, "0")

    return cambie_todos_aux(num, index + 1, size)

print(cambie_todos(13365439925))


# Ejercicio 4. Escriba una funci´on coincide(lista) que recibe una lista de n´umeros enteros e indique
# si algun elemento de la lista coincide con la suma de todos los que le preceden:
# >>> coincide([2, 4, 3, 9, 14]) → 2 + 4 + 3 = 9
# True
# >>> coincide([5, 6, 14, 18, 20, 41])
# False
# listacoincide=[2,4,3,9,14]
def coincide(lista):
    return coincide_aux(lista, 0, 0)

def coincide_aux(lista, suma, result):
    if lista.count(0) > 0:
        lista.remove(0)
        return coincide_aux(lista, suma, result)
    else:
        if result == 1:
            return True
        else:
            if lista == []:
                return False
            else:
                if suma == lista[0]:
                    result = 1
                    return coincide_aux(lista, suma, result)
                else:
                    suma = suma + lista[0]
                    return coincide_aux(lista[1:], suma, result)


print(coincide([0,1,1]))

# 5 Escriba una funci ́on recursivadivida(dig, num) que reciba un d ́ıgito 
# y un n ́umero enteroy obtenga dos n ́umeros, el primero compuesto por los 
# dıgitos mayores o iguales al d ́ıgitodado y el segundo compuesto por 
# los d ́ıgitos menores al d ́ıgito dado.

def divida(dig,num):
    if isinstance(num,int) and dig in range(0,10) :
        return mayores(dig,num,0,0) , menores(dig,num,0,0)
    else:
        return "ERROR"

def mayores(dig,num,potencia,resultado):
    if num == 0 :
        return resultado
    else:
        digito = num%10
        if digito>= dig :
            resultado =resultado + digito*10**potencia
            return mayores(dig,num//10,potencia+1,resultado)
        else:
            return mayores(dig,num//10,potencia,resultado)

def menores(dig,num,potencia,resultado):
    if num == 0 :
        return resultado
    else:
        digito = num%10
        if digito< dig :
            resultado = resultado + digito*10**potencia
            return menores(dig,num//10,potencia+1,resultado)
        else:
            return menores(dig,num//10,potencia,resultado)

# print(divida(4,12345678))

# _____________________________________________________________________________________________________________________________________
# Ejercicio 6
# Utilice recursividad de cola para implementar la siguiente sumatoria.
# Como funciòn debe recibir como parámetro un número que funcione como 
# límite superior(max_value)
def sumatoria(max_value):
    return sumatoria_aux(max_value,0)

def sumatoria_aux(max_value, resultado):
    if max_value == 0:
        return resultado
    else:
        resultado += 2*max_value**3 + 3*max_value**2 +1
        return sumatoria_aux(max_value -1,resultado)

# print(sumatoria(5))



