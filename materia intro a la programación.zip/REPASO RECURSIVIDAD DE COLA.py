#1. Escriba una funcion que reciba un numero (que debe ser entero) y retorne dos listas,
#una con los digitos entre 0 y 4 y otra con los digitos entre 5 y 9.
def menores_mayores(num):
    if isinstance(num,int):
        return menores_a_5(num,[]), mayores_a_4(num,[])
    else:
        return "ERROR"

def menores_a_5(num,lista_men_a_5):
    if num == 0 :
        return lista_men_a_5
    else:
        digito = num % 10
        if digito < 5:
            lista_men_a_5 += [digito]
            return menores_a_5(num//10,lista_men_a_5)
        else:
            return menores_a_5(num//10, lista_men_a_5)

def mayores_a_4(num,lista_may_a_4):
    if num == 0:
        return lista_may_a_4
    else:
        digito = num % 10
        if digito > 4:
            lista_may_a_4 += [digito]
            return mayores_a_4(num // 10, lista_may_a_4)
        else:
            return mayores_a_4(num // 10, lista_may_a_4)

#print(menores_mayores(123456789))

#2. Construya una funcion de nombre split(lista). Esta funcion toma una lista y la divide
#en sublistas usando como punto de corte cada vez que aparezca un cero.
def split(lista):
    if isinstance(lista,list):
        return split_aux(lista,0,[],[])
    else:
        return "ERROR"

def split_aux(lista,idx,lista_dividida,lista_total):
    if idx == len(lista):
        lista_total.append(lista_dividida)
        return lista_total
    else:
        if lista[idx] != 0 :
            lista_dividida.append(lista[idx])
            return split_aux(lista,idx+1,lista_dividida,lista_total)
        else:
            lista_total.append(lista_dividida)
            return split_aux(lista,idx+1,[],lista_total)


#print(split([1,2,3,4,0,1,2,3,4,0,5,6,7,8]))


#3. Escriba una funcion cambie todos(num) que reciba una numero entero y sustituya
#todos los valores que aparezcan 2 o mas veces por un cero.

#DUDA

#4. Escriba una funcion coincide(lista) que recibe una lista de numeros enteros e indique
#si algun elemento de la lista coincide con la suma de todos los que le preceden:
#> > > coincide([2, 4, 3, 9, 14]) - 2+4+3 =9
#True
#> > > coincide[1,2,5,3,7,8,1])
#False

def coincide(lista):
    if isinstance(lista,list):
        return coincide_aux(lista,0,0)
    else:
        return "ERROR"

def coincide_aux(lista,idx,suma_total):
    if idx == len(lista)-1:
        return False
    else:
        digito = lista[idx]
        suma_total += digito
        if suma_total == lista[idx+1]:
            return True
        else:
            return coincide_aux(lista,idx+1,suma_total)


#print(coincide([2, 4, 3, 9, 18]))
#print(coincide([1,2,5,3,7,8,1]))
#print(coincide([1,2,3,5,6,12,45,56]))



#5. Escriba una funcion recursive divida (dig, num) que reciba un digito y un numero entero
#y obtenga dos numeros, el primero compuesto por los digitos mayores o iguales al digito
#dado y el segundo compuesto por los digitos menores al digito dado.
def divida(dig,num):
    if isinstance(num,int) :
        return divida_mayores(num,dig,[]), divida_menores(num,dig,[])
    else:
        return "ERROR"

def divida_mayores(num,dig,lista_mayores):
    digito = num % 10
    if num == 0:
        return lista_mayores
    else:
        if digito >= dig:
            lista_mayores += [digito]
            return divida_mayores(num//10,dig,lista_mayores)
        else:
            return divida_mayores(num//10,dig,lista_mayores)

def divida_menores(num,dig,lista_menores):
    digito = num % 10
    if num == 0:
        return lista_menores
    else:
        if digito < dig:
            lista_menores += [digito]
            return divida_menores(num//10,dig,lista_menores)
        else:
            return divida_menores(num//10,dig,lista_menores)

#print(divida(5,123456789))


#6. Utilice recursivedad para implementar la siguiente sumatoria. La funcion debe recibir
#como parametro un numero que funcione como limite superior (mar_value).
#mar.value
#_ 2n' + 3n' + 1
def sumatoria(maxvalue):
    if isinstance(maxvalue,int) :
        return sumatoria_aux(maxvalue,1,0)
    else:
        return "ERROR"

def sumatoria_aux(maxvalue, n,resultado):
    if maxvalue < n:
        return resultado
    else:
        resultado += (2*n**3)+(3*n**2)+1

        return sumatoria_aux(maxvalue,n+1,resultado)

#print(sumatoria(5))

#Problemas examen
#1. Un cuadro semi-magico es una matriz m xn en la cual todas las filas que la componentsuman
#lo mismo. Por ejemplo, la matriz [[6,2,1], [5,4,0], [4,4,1]] seria un cuadro semimagico. Escrib
#una funcion recursiva semi (matriz) que reciba una matriz y verifique si el argumento dado
#es o no un cuadro semi-magico

#Ejemplo:
#semi ( [ [6, 2, 1] , [5, 4, 0] , [4,4,1]])
#> > > True
#semi ( [[6, 7, 1] , [13, 1,0]])
#> > > True
def matriz_semi_magica(matriz):
    #para verificar que sea una matriz
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return matriz_aux(matriz,0)
    else:
        return "ERROR"




def matriz_aux(matriz,idx):
    if idx == len(matriz)-1:
        return True
    else:
        if Suma_lista_en_matriz(matriz[idx],0,0) != Suma_lista_en_matriz(matriz[idx+1],0,0) :
            return False
        else:
            return matriz_aux(matriz,idx+1)

def Suma_lista_en_matriz(matriz,idx,suma_lista):
    if idx == len(matriz):
        return suma_lista
    else:
        suma_lista += matriz[idx]
        return Suma_lista_en_matriz(matriz,idx+1,suma_lista)

#print(matriz_semi_magica([[6,2,1], [5,4,0], [4,4,1]]))
#print(matriz_semi_magica([[6,2,1], [5,3,0], [4,4,0],[1,3,5]]))
#print(matriz_semi_magica([[6, 7, 1] , [13, 1,0]]))


#2. Escriba una funcion recursive ceros (matriz) que reciba una matriz de tamano m x n y
#devuelve una lista con las posiciones de la matriz que contienen ceros.
#Ejemplo:

#ceros ([0, 1, 2, 4], [9, 8, 0, 0], [5, 0, 3, 2]])
#>> > [[o, 0], [1, 2]. [1, 3], [2, 1]]
#ceros ( [5, 1, 2, 4], [9, 8, 5, 5], [5, 5, 3, 2]])
#> > >O
#def ceros(matriz):
    #para verificar que sea una matriz
    #if isinstance(matriz[0],list) and isinstance(matriz,list):
     #   return ceros_aux(matriz,)
    #else:
        #return "ERROR"


#Ejercicio 1
#1. Analice la siguiente serie numerica:
#2, 5, 7, 10, 12, 15, 17, 20 ...

#Determine su formula y construya una funcion recursive en cola llamada
#serie (n) que reciba como argumento un numero y genere la serie desde 2
#hasta el numero dado
#>>> serie(( 12)
#12, 5, 7, 10, (12)

#> > >
#serie (19)
#[2, 5, 7, 10, 12, 15, 17]



def serie(num_final):
    if isinstance(num_final,int) and num_final < 2 :
        return "ERROR"
    else:
        if num_final == 2:
            return [2]
        else:

            return serie_aux(num_final,3,2,[2])

def serie_aux(num_final,incremento,num_serie,resultado):
    secuencia = num_serie + incremento
    if secuencia <= num_final :
        resultado += [secuencia]
        if incremento == 2 :
            incremento = 3
            return serie_aux(num_final, incremento, secuencia, resultado)
        else:
            incremento = 2

            return serie_aux(num_final,incremento,secuencia,resultado)

    else:
        return resultado

#print(serie(53))


#2. Escriba una funcion frecuencia (lista) que reciba una lista de numeros y obtenga

#sublistas que indique cada numero y cuantas veces aparece.
#>>> frecuencia ( [9, 1, 7, 8])

#[[9, 1], [1, 1], [7, 1], [8, 1]]
#>>> frecuencia ( [1, 0, 0, 0, 0, 9])
#[[1, 1], [0, 4], [0, 4], [0, 4], [0, 4], [9, 1]]

def frecuencia(lista):
    if isinstance(lista,list):
        return frecuencia_aux(lista,0,[],[])
    else:
        return "ERROR"

def frecuencia_aux(lista,idx,lista_contar,lista_resultado):
    if idx == len(lista):
        return lista_resultado
    else:
        lista_contar += [lista[idx],contar_repetidos(lista,lista[idx],0,0)]
        lista_resultado += [lista_contar]
        return frecuencia_aux(lista,idx+1,[],lista_resultado)

def contar_repetidos(lista,num,idx,contador):
    if idx == len(lista):
        return contador
    else:
        if lista[idx] == num:
            contador += 1
            return contar_repetidos(lista,num,idx+1,contador)
        else:
            return contar_repetidos(lista, num, idx + 1, contador)


#print(frecuencia([1,1,2,45,5,66,66,2]))

#Realice una funcion en Python llamada Inviertelista(lista), que reciba como parametro una lista no nula
#de solo numeros enteros. La funcion debe invertir los elementos de la lista, tomando en consideracion que
#si hay listas anidadas tambien se deben de invertir. La funcion debe comportarse de la siguiente manera.
#> >> Inviertelista([1,3,5, [1,6,5]])

#> > > Inviertelista([2,3,4])
#[4,3.2]
#> > > Inviertelista([])
#Error

#[[5,6,1],5,3,1]
#> >> Inviertelista([23, [3,2],45,61,3])
#[3,61,45, [2,3],23]

def invierte_lista(lista):
    if isinstance(lista,list):
        return invierte_lista_aux(lista,-1,[])
    else:
        return "ERROR"

def invierte_lista_aux(lista,idx,lista_invertida):

    if -1*idx > len(lista):
        return lista_invertida
    else:
        if isinstance(lista[idx],int):
            lista_invertida += [lista[idx]]
            return invierte_lista_aux(lista,idx-1,lista_invertida)
        else:
            if isinstance(lista[idx],list):
                lista_invertida += [invierte_lista_aux(lista[idx],-1,[])]
                return invierte_lista_aux(lista,idx-1,lista_invertida)
            else:
                return "ERROR"

#print(invierte_lista([2,3,4]))
#print(invierte_lista([3,61,45, [2,3],23]))

# Ejercicio 3
# Escriba una funci´on cambie todos(num) que reciba una n´umero entero y sustituya
# todos los valores que aparezcan 2 o mas veces por un cero

def cambie_todos(num):
    if isinstance(num,int) and num >= 0:
        num_str = str(num)
        return cambie_todos_aux(num_str,0,"")

    else:
        return "ERROR"

def cambie_todos_aux(num_str,idx,str_resultado):
    if idx >= len(num_str):
        return str_resultado
    else:
        if contar_str(num_str,0,num_str[idx],0) > 1:
            str_resultado += "0"
            return cambie_todos_aux(num_str,idx+1,str_resultado)
        else:
            str_resultado += num_str[idx]
            return cambie_todos_aux(num_str, idx + 1,str_resultado)
#contar los caracteres que se repiten en un string

def contar_str(num_str,idx,dig,contador):
    if idx == len(num_str):
        return contador
    else:
        if num_str[idx] == dig:
            contador += 1
            return contar_str(num_str,idx+1,dig,contador)
        else:
            return contar_str(num_str, idx + 1, dig, contador)



#print(cambie_todos(3788310))



#6. Escriba una funcion producto_diagonal (matriz ) que reciba una matriz que
#debe ser nxn y que calcule el producto de la diagonal principal de una matriz
#cuadrada.

#>>> producto_diagonal ([ [2, 3], [4, 5]])

#10

def producto_diagonal(matriz):
    #para verificar que sea una matriz
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return producto_diagonal_aux(matriz,0,0,0)



    else:
        return "ERROR"

def producto_diagonal_aux(matriz,fila,columna,suma_diagonales):
    if fila == len(matriz):
        return suma_diagonales
    else:

        if fila != columna:
            return producto_diagonal_aux(matriz, fila, columna + 1, suma_diagonales)

        else:
            num_int = matriz[fila][columna]

            suma_diagonales = num_int + suma_diagonales
            return producto_diagonal_aux(matriz, fila + 1, columna, suma_diagonales)


#print(producto_diagonal([[2,3,4],[4,5,4],[1,3,4]]))




#4. Escriba una funcion recursive llamada shiftx (num, x) que reciba un numero
#entero num y una cantidad de posiciones x, la cual debe ser menor que la cantidad
#de digitos de num y debe rotar a la derecha los digitos del numero segun la cantidad
#de veces especificada en x.
#>>> shiftx (4321, 1)#1432
#>>> shiftx (4321, 2)#2143
#>>> shiftx (4321, 4)4321
#>>> shiftx (10000, 2)100
#>>> shiftx (4321, 3)3214
#>>> shiftx (4321, 5)Error



#7. Escriba una funcion recursive borde(matriz) que reciba una matriz y genere una lista
#con los elementos de la matriz que conforman su borde.

#> > > borde([[1,2,3,4,5], [6,7,8,9, 10], [11,12,13,14,15], [16,17,18,19,20]])
#[1,2,3,4,5,6,10,11,15,16,17,18,19,20]




def borde(matriz):
    #para verificar que sea una matriz
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return borde_aux(matriz,0,matriz[0])
    else:
        return "ERROR"

def borde_aux(matriz,idx,lista_borde):
    if len(matriz) == 0:
        return []
    if len(matriz) == 1:
        return matriz[idx]
    elif len(matriz) == 2:
        return matriz[idx] + matriz[idx+1]
    else:
        if idx+1 == len(matriz)-1:
            lista_borde += matriz[idx+1]
            return lista_borde
        else:
            lista_borde += [matriz[idx+1][0] , matriz[idx+1][-1]]
            return borde_aux(matriz,idx+1,lista_borde)

#print(borde([[1,2,3,4,5], [6,7,8,9, 10], [11,12,13,14,15], [16,17,18,19,20]]))





#Escriba una funcion llamada elimine(num, dig) que reciba un numero entero y un digito
#valido y elimine los digitos del numero que sean iguales al digito dado.
def elimine(num,dig):
    if isinstance(num,int) and dig in range(0,10):
        return elimine_aux(num,dig,0,0)
    else:
        return "Error"

def elimine_aux(num,dig,idx,resultado):
    if num == 0:
        return resultado
    else:
        elemento = num % 10
        if elemento == dig:
            return elimine_aux(num//10,dig,idx,resultado)
        else:
            resultado += (elemento) * (10**idx)
            return elimine_aux(num//10,dig,idx+1,resultado)

#print(elimine(19990,9))



#10. Escriba una funcion recursive triangular_superior(matriz ) que debe recibir una matriz
#de tamano mum y debe determinar si la matriz es una matriz triangular superior o
#no. Una matriz es triangular superior si todos los elementos bajo su diagonal (sin

#considerarla) son ceros.
#> > > triangular_superior([[1, 8, 3], [0, 2, 4], [0, 0, 5]])
#True

def triangulo_superior(matriz):
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return triangulo_superior_aux(matriz,0)
    else:
        return "ERROR"

def triangulo_superior_aux(matriz,fila):
    if fila == len(matriz):
        return True
    else:
        if matriz[fila][fila] == 0:
            return False
        else:
            if verificar_ceros(matriz[fila],fila):
                return triangulo_superior_aux(matriz,fila+1)
            else:
                return False

#Verificar ceros de una matriz
def verificar_ceros(matriz,idx):
    if idx-1 <0:
        return True
    else:
        if matriz[idx-1] == 0:
            return verificar_ceros(matriz,idx-1)
        else:
            return False


#print(triangulo_superior([[1, 8, 3], [0, 2, 4], [0, 0, 5]]))
#print(triangulo_superior([[1, 0, 0], [1, 2, 0], [2, 4, 4]]))


#10. Escriba una funcion recursive triangular_inferior(matriz ) que debe recibir una matriz
#de tamano mxm y debe determinar si la matriz es una matriz triangular INFERIOR o
#no. Una matriz es triangular INFERIOR si todos los elementos arriba de su diagonal(sin
#considerarla) son ceros.
#> > > triangular_INFERIOR([[1, 0, 0], [1, 2, 0], [2, 4, 4]])
#True

def triangulo_inferior(matriz):
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return triangulo_inferior_aux(matriz,0)
    else:
        return "ERROR"

def triangulo_inferior_aux(matriz,idx):
    if idx == len(matriz):
        return True
    else:
        if matriz[idx][idx] == 0:
            return False
        else:
            if verificar_ceros(matriz[idx], idx):
                return triangulo_inferior_aux(matriz, idx + 1)
            else:
                return False

    # Verificar ceros de una matriz


def verificar_ceros(matriz, indice):
    if indice + 1 == len(matriz):
        return True
    else:
        if matriz[indice + 1] == 0:
            return verificar_ceros(matriz, indice + 1)
        else:
            return False



#print(triangulo_inferior([[1, 0, 0], [1, 2, 0], [2, 4, 4]]))

#6. Escriba una funcion llamada natural(lista) que reciba una lista de numeros desorde-
#nados y produzca una lista de listas, donde cada sublista mantiene el orden natural
#de la lista original. Es decir, se van a tener sublistas que mantienen el orden de sus
#componentes, pero que terminan si el siguiente numero en la lista original es menor al

#actual.
#> > > natural([3, 4, 5, 1, 2, 3, 4, 7, 3, 2, 1])
#[3, 4, 5], [1, 2, 3, 4, 7], [3], [2], [1]]

def natural(lista):
    if isinstance(lista,list):
        return natural_aux(lista,0,[])
    else:
        return "ERROR"

def natural_aux(lista,idx,lista_natural):
    if idx + 1 == len(lista):
        lista_natural += [lista]
        return lista_natural
    else:
        if lista[idx] < lista[idx+1]:

            return natural_aux(lista,idx+1,lista_natural)
        else:

            lista_temporal = [lista[0:idx+1]]
            lista_natural += lista_temporal
            return natural_aux(lista[idx+1:],0,lista_natural)

#print(natural([3, 4, 5, 1, 2, 3, 4, 7, 3, 2, 1]))
#print(natural([3, 4, 5, 1, 2, 3, 4, 7, 5, 6, 7]))


#1. Escriba una funcion recursive llamada repetidos que reciba una lista con numeros
#enteros y un numero entero. La funcion debe verificar que la lista y sus sublistas
#unicamente contienen numeros enteros. Luego, debera determinar la cantidad de
#veces que aparece el numero entero en la lista. Nota: la lista puede contener otras listas
#dentro.

#" > > > repetidos( [0,1, [2,3,4],0,2], 0)
#2
#" >> > repetidos( [0,1, [2, [3],4],0,2], 4)
#1

#2
def raiz(numero,error):

    return raiz_aux(numero, error, 1)

def raiz_aux(numero, error_min, resultado) :

    cub_root=numero**(1/3)#se cambia
    error_act=abs((resultado-cub_root)/cub_root)

    if error_act<=error_min:
        return resultado

    else:
        resultado=(1/3)*((numero/ (resultado**2)) + 2*resultado)#se cambia
        return raiz_aux(numero, error_min, resultado)



#print(raiz(9, 0.00001))


#3. Escriba una funcion recursive col mayor que reciba una matriz de tamano mxn. \
#Esta funcion retornara una tupla
#con la columna con el mayor producto y su resultado.
#" >> > col_mayor([[1,2,3], [4,5,6], [7,8,9], [10,11,12]])
#([3,6,9,12], 1944)


matriz = [[1,2,3], [4,5,6], [7,8,9], [10,11,12]]
def col_mayor(matriz):
    if isinstance(matriz[0],list) and isinstance(matriz,list):
        return col_mayor_aux(matriz,0, [],1)
    else:
        return "error"

def col_mayor_aux(matriz,idx,lista_mayores, multiplicacion):
    if idx == len(matriz):
        return lista_mayores ,multiplicacion
    else:

        lista_mayores += [numero_mayor(matriz[idx],0,matriz[idx][0])]
        multiplicacion *= numero_mayor(matriz[idx],0,matriz[idx][0])
        return col_mayor_aux(matriz,idx +1, lista_mayores,multiplicacion)

def numero_mayor(matriz,i,ele_mayor):
    if i == len(matriz):
        return ele_mayor
    if matriz[i] > ele_mayor:
        ele_mayor = matriz[i]
        return numero_mayor(matriz,i+1,ele_mayor)
    else:
        return numero_mayor(matriz, i + 1, ele_mayor)

#print(col_mayor(matriz))

#4. Escriba una funcion reemplazar que reciba un string
#y reemplace #aquellas letras que
#se repiten u#n numero de veces divisible por 3, por un *.
#La funcion d#ebe comportarse #como en los siguientes ejemplos:
#= > > > reem#plazar('holaoao')
#h*la*a*
#> > > reemplazar('introytallerl')
#'introyta* *er*'
palabra = "holaoao"
def reemplazar(palabra):
    if isinstance(palabra,str):
        return reemplazar_aux(palabra,0,"")
    else:
        return "CARACTER DIGITADO NO ES STRING"

def reemplazar_aux(palabra,idx,p_nueva):
    string_2 = ""
    if idx == len(palabra):
        return p_nueva
    else:
        if contar_letras(palabra,palabra[idx],0,0) % 3 == 0:
            palabra[idx] = "*"
            p_nueva += palabra[0:idx+1]
            return reemplazar_aux(palabra, idx+1,p_nueva)
        else:
            palabra = palabra[idx:-1]
            return reemplazar_aux(palabra,idx+1,p_nueva)



def contar_letras(palabra,letra,i,contador):
    if i == len(palabra):
        return contador
    else:
        if palabra[i] == letra:
            contador += 1
            return contar_letras(palabra,letra,i+1,contador)
        else:
            return contar_letras(palabra, letra, i+1, contador)


#print()





