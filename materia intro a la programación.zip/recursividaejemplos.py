# Recursividad funciòn se invoca a sì misma
# Funcion que suma los digitos de una función cualquiera
# Los ejercicios de recursividad se dividen en dos partes,
# Caso base y caso inductivo
def sum_Digitos(num):
# Caso base: Caso en el que se terminan los casos recursivos
# Hay que irse acercando al caso base, debido 
# a que si no, la función nunca va a terminar
    if num==0 :
        return 0
# Caso inductivo: Caso en el que se siguen haciendo llamadas recursivas
    else:
# Dentro de la misma función se llama a la misma función, 
# por lo que está definida a sí misma
        return  num%10 + sum_Digitos(num//10)

# print(sum_Digitos(2168))

# Para eliminar el ùltimo dígito de un número 12345//10=12345
# Para obtener un dígito se usa operación módulo 123456%10=6
# Si número es igual a cero, retornar 0, si no es 0, se retorna la llamada
#a la función, agarre el último dígito y súmelo a la última llamada de la 
# función. Se va llegando al caso base mientras se van evaluando los 
# parámetros de la función



# Ejemplo 1  
# Escriba una función que reciba un número entero
#  y un dígito y debe contar las veces que ese dígito aparece en el número 

# Crear el caso base de la función
# Como los valores de entrada son num y dig, se escriben
# Dentro de la función
def aparece(num, dig):
# Como la función posee restricciones, se tiene que realizar una función 
# principal que determine las restricciones y una función auxiliar
# que me haga la función

# Función principal.
# Rango de 0 a 9 debido a que el número del final no se cuenta
    if dig in range(0,10):
        if isinstance(num,int) and isinstance(num,int) :
# Esto ocurre debido a que cero puede aparecer 1 vez en el número
            if num !=0 and dig !=0 :
                return aparece_aux(num, dig)
            else: 
                return 1
        else: 
            return "ERROR"

    #  Si el dígito se encuentra en el rango de 0 a 9 y el número
    # es entero y mayor a cero, entonces se puede realizar la función
    # auxiliar
    # Si no ocurre esto, entonces retornar error

def aparece_aux(num, dig):
# Definir la función auxiliar en la cual se va a realizar el proceso
# Hacer el caso base, es decir, el caso al que va a tender la funcion
    digito= num % 10
    if num == 0 :
        return 0
# Caso inductivo en donde se va a hacer la función
    else: 
        if (digito == dig ):
            return 1 + aparece_aux(num//10,dig)
        else:
            return aparece_aux(num//10, dig)
    
# print(aparece(12344454, 4))


# Ejemplo 3 
# Escriba una función que reciba un número entero y diga cuántos números pares e impares tiene 
#  Realizar la función principal del programa
# Función principal
def pares_impares(numero) :
    if isinstance(numero,int) and numero>=0 :
        print("La cantidad de dígitos pares es {} e impares es {}".format(pares(numero), impares(numero)))
    else: 
        return "Debe escribir un número entero mayor a 0"
# Función auxiliar 
def pares(numero):
    if numero == 0:
        return 0
    else: 
        digito1 = numero%10
        if digito1%2 == 0: 
            return 1+ pares(numero//10)
        else: 
            return 0 + pares(numero//10)
# Toda función auxiliar contiene un caso base y un caso inductivo
def impares(numero) :
    if numero == 0: 
        return 0
    else:
        digito1=numero%10
        if digito1%2 != 0 :
            return 1+ impares(numero//10)
        else: 
            return 0 + impares(numero//10)

# pares_impares(7298192)
 
    
# VIDEO 2
# Hacer una función que reciba un número entero y cree otro número con los dígitos pares del número recibido 
# 123456 -- 246

# Todo número se puede descomponer multiplicándolo por 10
# Exponente decreciente. El 10 permanece invariable

def forme_par(num):
    if (isinstance(num,int) and num >=0):
        return forme_par_aux(num, 0)
        # Retorne el número y una potencia
    else: 
        return "ERROR"
    
   
def forme_par_aux(num, potencia):
    if(num == 0):
        return 0
    else:
        digit = num % 10
        if (digit % 2 == 0 ):
            return digit*10**potencia + forme_par_aux(num//10, potencia+1)
        else:
            return 0 + forme_par_aux(num//10,potencia)


# print(forme_par(1234560))

# Escriba una funcion que reciba un numero(que debe ser entero) y retorne dos listas
# una con los digitos entre 0 y 4 y otra con los dígitos de 5 al 9

def division_digitos(numero) :
        if (isinstance(numero,int) and numero >=0):
            return digitos_menoresa5(numero), digitos_mayoresa5(numero)
        else:
            return "error"

def digitos_menoresa5(numero):
    if (numero== 0):
        return []
    else: 
        digito1= numero %10
        if digito1<=4 :
            return  (digitos_menoresa5(numero//10)) + [digito1]
        else: 
            return (digitos_menoresa5(numero//10))
        
def digitos_mayoresa5(numero):
    if(numero== 0 ):
        return []
    else: 
        digito= numero % 10
        if (digito>=5):
            return (digitos_mayoresa5(numero//10))+ [digito]
        else: 
            return (digitos_mayoresa5(numero//10))

# print(division_digitos(12345678))

# Escriba una función llamada elimine(num, dig) que reciba un número entero y un dígito válido
# y elimine los dígitos del número que sean iguales al dígito dado

def elimine(num, dig):
    if dig in range(0,10):
        if isinstance(num,int) and num>=0 :
            return elimine_aux(num,dig, 0)
        else:
            return "ERROR"

def elimine_aux(num, dig, potencia):
    if num == 0 : 
        return 0
    else:
        digito= num % 10
        if digito == dig :
            return (elimine_aux(num//10, dig, potencia))
        else:
            return digito*10**potencia + elimine_aux(num//10,dig,potencia+1) 

# print(elimine(123444454,4))


#  Construya una funci ́on de nombresplit(lista).  
# Esta funcion toma una lista y la divideen sublistas usando 
# como punto de corte cada vez que aparezca un cero.
def split(lista):
    if 0 in lista:
        # Mediante este código se hace la lista desde el índice 0 hasta el
        # ìndice en donde se encuentra el dígito 0
        regreso=lista[0:lista.index(0)]
# Aquì se elimina la sublista de la lista c
        del lista[0:lista.index(0)+1]
        return (regreso,split(lista))
    else:
        return lista
# print(split([1,2,3,0,1,4,0,5,4,5]))



# 4 Escriba una funcion cambie_todos que reciba un número enterio
# y sustituya todos los valores que aparezcan 2 o más veces por un cero
# Ayuda en este no entiendo
def cambiatodos(num):
    # En este caso se está evaluando si el número es  entero, además  que se está 
    if isinstance(num,int) and num > 0:
        rep=repetidos(num)
        print(cambiatodosaux(num,0,rep))
    else: print("error")

def contador(num,comparador):
    suma=0
    dig = num%10
    if num !=0:
        if dig == comparador:
            return 1 + contador(num//10,comparador)
        else:
            return contador(num//10,comparador)
    else:
        return 0

def repetidos(num):
    listarepetidos=[]
    for i in range(1,10):
        if contador(num,i) > 1:
            listarepetidos.append(i)
    return listarepetidos


def cambiatodosaux(num,exponente,rep):
    dig = num%10
    if num !=0:
        if dig in rep:
            return (dig*0) + cambiatodosaux(num//10,exponente+1,rep)
        else:
            return dig*(10**exponente)+ cambiatodosaux(num//10,exponente+1,rep)
    else: return 0

cambiatodos(13365439925)


# 5. Escriba una funcion coincide(lista) que recibe una lista de numeros 
# enteros e  indique si alg ́un elemento 
# de la lista coincide con la suma de todos los que le preceden:
# función coincide lista

listacoincide=[2,4,3,9,14]

def sumalista(lista):
    if lista == []:
        return 0
    else:
        valor = lista[0]
        del lista[0]
        return valor + sumalista(lista)

def coincideaux(lista):
    i=0
    if lista != []:
        if lista[-1] == sumalista(lista[0:(len(lista)-1)]):
            i=i+1
        else: i=i
        del lista[-1]
        return coincideaux(lista)+i
    else:
        return 0

def coincide(lista):
    if coincideaux(lista)==0:
        print("no coincide")
    else:
        print("coincide")

# coincide([2,4,6,8,10])

# 6 Escriba una funci ́on llamadanatural(lista) que reciba una lista de 
# numeros desordenados y  produzca  una  lista  de  listas,  
# donde  cada  sublista  mantiene  el  orden  natural de la lista original.
# Es decir, se van a tener sublistas que mantienen el orden de 
# suscomponentes, pero que terminan si el siguiente n ́umero 
# en la lista original es menor al actual.

def natural(lista):
    if isinstance(lista,list):
        listaaimprimir=naturalaux(lista,1)
    print(listaaimprimir)


def naturalaux(lista,i):
    if len(lista) > i:
        if lista[i-1] > lista[i]:
            nuevalista=lista[0:i]
            del lista[0:i]
            i=1
            return [nuevalista] + naturalaux(lista,i)
        else:
            i=i+1
            return naturalaux(lista,i)
    else: return [lista]
listanatural=[3,4,5,1,2,3,4,7,3,2,1,6,7,9,0,10,32]

natural(listanatural)




#7 Escriba una funci ́on recursivaborde(matriz) que reciba una matriz
#  y genere una lista con los elementos de la matriz que conforman su borde.
matriz=[[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,15],[16,17,18,19,20]]

for i in matriz:
    for j in i:
        print(j,end=" ")
    print(" ")


def laterales(matriz):
    bordederecho=[]
    bordeizquierdo=[]
    for i in matriz[0]:
        bordeizquierdo.append(i)
    for i in matriz[-1]:
        bordederecho.append(i)
    return bordeizquierdo + bordederecho

def superiorinferior(matriz):
    if len(matriz) > 2:
        elementosuperior=matriz[1][0]
        elementoinferior=matriz[1][-1]
        del matriz[1]
        return [elementosuperior]+[elementoinferior]+superiorinferior(matriz)
    else: return []



def borde(matriz):
    listaborde=(laterales(matriz)+superiorinferior(matriz))
    print(listaborde)
borde(matriz)


# 8 Escriba una funci ́on recursivadivida(dig, num) que reciba un d ́ıgito 
# y un n ́umero enteroy obtenga dos n ́umeros, el primero compuesto por los 
# dıgitos mayores o iguales al d ́ıgitodado y el segundo compuesto por 
# los d ́ıgitos menores al d ́ıgito dado.
def mayor(num,dig,expomayor):
    if num==0:
        return 0
    else:
        if num%10 >= dig:
           return (num%10)*(10**expomayor)+mayor(num//10,dig,expomayor+1)
        else:
            return mayor(num // 10, dig, expomayor)

def menor(num,dig,expomenor):
    if num==0:
        return 0
    else:
        if dig>(num%10):
           return (num%10)*(10**expomenor)+menor(num//10,dig,expomenor+1)
        else:
            return menor(num // 10, dig, expomenor)

def divida(num,dig):
    if isinstance(num,int) and num>0 and isinstance(dig,int) and dig>0:
        print(menor(num,dig,0))
        print(mayor(num,dig,0))
    else: print("error")
# divida(113355887,5)

# 9 Utilice recursividad para implementar la siguiente sumatoria.  
# La funci ́on debe recibircomo par ́ametro un n ́umero que funcione como 
# lımite superior (max_value).
def sumatoriaaux(MaxValue,n):
    if MaxValue >= n:
        return (2*n+n**(1/2))/(n**3+n**(1/2)) + sumatoriaaux(MaxValue,(n+1))
    else: return 0

def Sumatoria(MaxValue):
    if isinstance(MaxValue,int):
        print(sumatoriaaux(MaxValue,1))
    else: print("error")
Sumatoria(5)


# 10 Escriba una funci ́on recursivatriangularsuperior(matriz) que debe 
# recibir una matrizde tama ̃nomxmy debe determinar si la matriz es una 
# matriz triangular superior ono.   Una  matriz  es  triangular  superior 
#  si  todos  los  elementos  bajo  su  diagonal  (sinconsiderarla) son 
# ceros.
def TriangularSuperiorAux(matriz,j):
    if len(matriz) == 1:
        return 0
    else:
         if matriz[1][:j].count(0)!=j:
            del matriz[1]
            return 1+TriangularSuperiorAux(matriz,j+1)
         else:
            del matriz[1]
            return TriangularSuperiorAux(matriz,j+1)

def TriangularSuperior(matriz):
    i=0
    for a in range(0,len(matriz)):
        if matriz[0]== [] or len(matriz) > len(matriz[a]):
            i=i+1
    if i != 0:
        print("error")
    else:
        if TriangularSuperiorAux(matriz,1) == 0:
                print("true")
        else: print("false")

matriztriangular=[[1,9,8,2], [0,0,2,5],[0,0,0,6],[0,0,0,1]]
#TriangularSuperior(matriztriangular)

# 11 Escriba una funci ́on recursiva que implemente la sucesion de Fibonacci
#la cual tiene lasiguiente definicion:fibonacci(0) = 0fibonacci(1) = 
# 1fibonacci(n)=fibonacci(n-1)+fibonacci(n-2)
def fibonacciaux(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacciaux(n-1) + fibonacciaux(n-2)

def fibonacci(n):
    if n >=0:
        print(fibonacciaux(n))
    else:
        print("error")

#fibonacci(9)


#12 Escriba una funcion multi(num) (en la cual num es un valor entre 2y100)
#  que en-cuentre todas las parejas (sin importar el orden) de n umeros 
# que multiplicados dan el numero dado.
def NumAux(num,i):
     if 100>=i:
         for j in range(1,102):
             if i*j == num:
                 pareja=[i,j]
                 return [pareja] + NumAux(num,i+1)
             elif j > 100:
                 return NumAux(num,i+1)
     else:
         return []
def multi(num):
    if isinstance(num,int) and num > 0:
        lista=NumAux(num,1)
        inicio=((len(lista)//2))
        final=len(lista)
        if len(lista)%2 ==0:
            del lista[inicio:final]
        else:
            del lista[inicio+1:final]
        print(lista)
    else: print("error")

# multi(120)



#  EXAMEN PARCIAL 1 SIMULACRO
# 1. Escriba una funcioon recursiva en pila llamada diferencia, que reciba 
# dos numeros enteros y obtenga comO resultado dos numeros, el primero 
# compuesto por los digitos del primer n umero que no pertenecen al segundo
# numero y el segundo formado por los elementos del segundo numero que no pertenecen al primer numero.
def diferencia(num1, num2):
	if num1 == num2:
		return 0, 0
	else:
		return int(diferencia_num1(num1, num2)), int(diferencia_num2(num2, num1))


def diferencia_num1(num_original, resta):
	if num_original == 0:
		return ""
	if str(num_original % 10) in list(str(resta)):
		return diferencia_num1(num_original // 10, resta)
	else:
		return diferencia_num1(num_original // 10, resta) + str(num_original % 10)


def diferencia_num2(num_original, resta):
	if num_original == 0:
		return ""
	if str(num_original % 10) in list(str(resta)):
		return diferencia_num1(num_original // 10, resta)
	else:
		return diferencia_num1(num_original // 10, resta) + str(num_original % 10)



# 2. Escriba una funcion recursiva en pila que reste un digito especico a todos los digitos de otro numero.
# si la resta es negativa se debe colocar un cero.
def restard(dig, num):
	if num == 0:
		return ""
	if num % 10 - dig > 0:
		return restard(dig, num // 10) + str(num % 10 - dig)
	else:
		return restard(dig, num // 10) + "0"

# 3. Escribir una funcion recursiva, denominada contar(lista), que reciba como argumento una lista compuesta por
# elementos y sublistas y obtenga como resultado la cantidad de todos los elementos de la lista y de todas sus
# sublistas.
def contar(lista):
	if len(lista)==0:
		return 0
	return sub_dividir(lista)

def sub_dividir(lista):
	if len(lista)==0:
		return 0
	if type(lista[0])==list:
		# Sumamos los elementos de lista[0] al final
		lista=lista+lista[0]
		# Eliminamos el primer elemento (que era una lista) porque ya añadimos sus elementos al final de la lista
		lista=lista[1:]
		return sub_dividir(lista)
	else:
		return 1+sub_dividir(lista[1:])