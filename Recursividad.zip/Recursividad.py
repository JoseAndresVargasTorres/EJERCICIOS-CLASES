# Definición recursividad
# Es el proceso en el que una función se invoca a sí misma
# Ejercicio ejemplo
def suma_digitos(num33):
# Caso base
    if num33==0 :
        return 0
    else:
        return num33%10+suma_digitos(num33//10)

# print(suma_digitos(2987))


# Ejercicio 1
# Escriba una función que reciba un número entero y un dígito y debe 
# contar las veces que ese dígito aparece en el número
def aparece(num331,dig):
    if dig in range(0,10):
        if isinstance(num331, int) and isinstance(dig, int):
            if num331 !=0 and dig !=0 :
                return aparece_aux
            else: 
                return 1
        else: 
            return "Error"

def aparece_aux(num331, dig) :
    if num331==0 :
        return 0
    elif num331%10 == dig :
        return 1 + aparece_aux(num331//10, dig)
    else:
        return aparece_aux(num331//10,dig)

# print(aparece(128238888,8))
# print(aparece_aux(128238888,8))

# Ejemplo 2
# Escriba una función que reciba un número entero y diga
# Cuantos números pares e impares tiene
# Entrada: num333
# Salida: Cantidad de pares e impares que posee el num333
# Restricciones: Número entero mayor a cero.

def pares_impares(num3):
    if isinstance(num3,int) and num3>= 0 :
        return pares(num3), impares(num3)
    else: 
        print("Escriba un número mayor o igual a 0")

def pares(num3):
    if num3 != 0 :
        if num3%2 == 0 :
            return 1 + pares(num3//10)
        else: 
            return pares (num3//10)
    else: 
        return 0

def impares(num3):
    if num3 != 0: 
        if num3%2 !=0 :
            return 1 + impares(num3//10) 
        else:
            return impares(num3//10)
    else: 
        return 0
    
# print(pares_impares(4564747))

#Repaso recursividad  
# Ejercicio 3
# Hacer una función que reciba un número entero
# y cree otro número con los dígitos pares del número recibido
# E: n_ent
# S: Número formado por los dígitos pares
# R: Número debe ser igual o mayor a cero

def entero_par(n_ent):
    if isinstance(n_ent, int) and n_ent>=0 :
        return union_pares(n_ent, 0)
    else: 
        print("Debe escribir un número mayor o igual a cero")

def union_pares(n_ent, potencia):
    if (n_ent == 0) :
        return 0
    else: 
        digito= n_ent %10 
    if n_ent %2 == 0 :
        par = n_ent%10
        return par*10**potencia + union_pares(n_ent//10, potencia + 1)
    else:
        return 0 + union_pares(n_ent//10, potencia)

# print(entero_par(123890))

