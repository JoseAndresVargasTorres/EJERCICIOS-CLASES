
"""
def frecuencias(lista):
    if isinstance(lista,list):
        return frecuencias_aux(lista,0,[],[])
    else:
        return "ERROR"

def frecuencias_aux(lista,i,lista_comparar,resultado):
    lista_comparar = set(lista)
    if lista == [] :
        return resultado
    else:
        if i in lista :
            result = result + [lista.count(i)]
            
            i= i + 1
            return frecuencias_aux(lista,i,result)
        else:
            result = result + lista.append(0)
            i= i +1
            return frecuencias_aux(lista,)

"""

# print(frecuencias([1,1,2,1,4])  


# Escriba una funci´on en recursividad de cola llamada cambia(num),
#  que reciba un n´umero
# entero y cambie los d´ıgitos que sean divisibles entre 4, por un cero.
# >>> cambia(1488)
# 1000
# >>> cambia(72571)
# 72571

def cambia(num):
    if isinstance(num,int):
        num_a_comparar = num
        return cambia_aux(num,0,num_a_comparar,0)
    else:
        return "ERROR"


def contar_repetidos(num,dig,cont):
    if num == 0 :
        return cont
    else:
        digito_a_comparar = num % 10
        if digito_a_comparar == dig:
            return contar_repetidos(num//10,dig,cont+1)
        else:
            return contar_repetidos(num//10,dig,cont)

def cambia_aux(num,potencia,num_a_comparar,resultado):
    if num == 0 :
        return resultado
    else:
        digito = num %10
        if contar_repetidos(num_a_comparar,digito,0) > 1  :
            resultado= resultado + digito*10**potencia
            return cambia_aux(num//10,potencia + 1,num_a_comparar,resultado)
        else:
            return cambia_aux(num//10,potencia+1,num_a_comparar,resultado)

print(cambia(144880456))
        
