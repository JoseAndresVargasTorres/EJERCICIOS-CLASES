# Ejemplo 1  
# Escriba una función que reciba un número entero
#  y un dígito y debe contar las veces que ese dígito aparece en el número
def sum_digitos(num,dig):
    if isinstance(num,int) and num>=0 :
        if dig in range(0,10):
            return sum_digitos_aux(num,dig)
        else: 
            return "ERROR"
    
def sum_digitos_aux(num,dig):
    if num==0 :
        return 0
    else:
        digito=num%10
        if digito== dig :
            return 1 + sum_digitos_aux(num//10,dig)
        else:
            return sum_digitos_aux(num//10,dig)


# print(sum_digitos(12344454,4))

# Ejemplo 3 
# Escriba una función que reciba un número entero y diga cuántos números pares e impares tiene 
def pares_impares(num):
    if isinstance(num,int) and num>=0 :
        return pares_aux(num) , impares_aux(num)
    else:
        return "ERROR"
# RECORDAR HACER EL CASO EN EL QUE LA FUNCIÓN SE ACABA

def pares_aux(num):
    if num == 0 :
        return 0
    else:
        digito=num%10
        if digito%2 == 0 :
            return 1 + pares_aux(num//10)
        else: 
            return 0 + pares_aux(num//10)

def impares_aux(num):
    if num == 0 :
        return 0
    else:
        digito=num%10
        if digito%2 != 0 :
            return 1+ impares_aux(num//10)
        else:
            return 0 + impares_aux(num//10)

# print(pares_impares(1234))

# VIDEO 2
# Hacer una función que reciba un número entero y cree otro número con los dígitos pares del número recibido 
# 123456 -- 246
def nuevo_num(num):
    if isinstance(num,int) and num>=0 :
        return nuevo_num_aux(num,0)
    else:
        return "ERROR"

def nuevo_num_aux(num,potencia):
    if num == 0 :
        return 0
    else:
        digito=num%10
        if digito%2 == 0 :
            return digito*10**potencia + nuevo_num_aux(num//10,potencia + 1)
        else:
            return 0 + nuevo_num_aux(num//10, potencia)

# print(nuevo_num(123456))

# Escriba una funcion que reciba un numero(que debe ser entero) y retorne dos listas
# una con los digitos entre 0 y 4 y otra con los dígitos de 5 al 9
def num_listas(num):
    if isinstance(num,int) and num>=0 :
        return num_listas_0a4(num) , num_listas_5a9(num)
    else:
        # Colocar el return
        return "ERROR"

def num_listas_0a4(num):
    if num == 0 :
        # Cuando se tiene como salida listas, el caso base debe ser []
        return []
    else:
        digito = num%10
        if digito<5 :
            # Colocar paréntensis en el caso recursivo
            return [digito] + (num_listas_0a4(num//10))
        else:
            return (num_listas_0a4(num//10))

def num_listas_5a9(num):
    if num == 0 :
        return []
    else:
        digito = num%10
        if digito>4 :
            return [digito] + (num_listas_5a9(num//10)) 
        else:
            return (num_listas_5a9(num//10))

# print(num_listas(12345678))

# Escriba una función llamada elimine(num, dig) que reciba un número entero y un dígito válido
# y elimine los dígitos del número que sean iguales al dígito dado
def elimine(num,dig):
    if isinstance(num,int) and num>=0 :
        if dig in range(0,10) :
            return elimine_aux(num,dig,0)
        else:
            return "ERROR"
   
# Colocar la potencia para ir formando correctamente el número
def elimine_aux(num,dig,potencia):
    if num == 0 :
        return 0
    else:
        digito= num%10
        if digito == dig :
            return 0 + (elimine_aux(num//10,dig,potencia))
        else:
            # Utilizar la potencia para ir acomodando el número nuevo
            return digito*10**potencia + (elimine_aux(num//10,dig,potencia+1))

# print(elimine(124444435,4))

#  Construya una funci ́on de nombre split(lista).  
# Esta funcion toma una lista y la divideen sublistas usando 
# como punto de corte cada vez que aparezca un cero.
def split(lista):
    if 0 in lista :
        regreso= lista[0:lista.index(0)]
        # Aquí se está poniendo que regreso equivale ir desde el punto de inicio hasta donde aparezca un cero
        del lista[0:lista.index(0)+1]
        return (regreso,split(lista))
    else:
        return lista

# print(split([1,2,3,0,1,4,0,5,4,5]))
# Preguntar si está bien hacerlo así 


# 4 Escriba una funcion cambie_todos que reciba un número enterio
# y sustituya todos los valores que aparezcan 2 o más veces por un cero
# def cambie_todos(num):
    # if isinstance(num,int) and num>=0 :
        # return 
    # PREGUNTAR EN HORAS CONSULTA

# 5. Escriba una funcion coincide(lista) que recibe una lista de numeros 
# enteros e  indique si alg ́un elemento 
# de la lista coincide con la suma de todos los que le preceden:
# función coincide lista

def suma_lista(lista):
    if lista == [] :
        return 0
    else:
        valor = lista[0]
        del lista[0]
        return valor + suma_lista(lista)

def coincide_aux(lista):
    i=0
    if lista != [] :
        # Colocar los paréntesis en el len
        if lista[-1] == suma_lista(lista[0:(len(lista)-1)]):
            i=i+1
        else: i=i
        del lista[-1]
            # Colocar el + i para que luega se pueda comparar con 0
        return coincide_aux(lista)+i
    else:
        return 0

def coincide(lista):
    if coincide_aux(lista) == 0 :
        print("NO COINCIDE")
    else:
        print("COINCIDE")

# coincide([2,4,6,8,10])

# 6 Escriba una funci ́on llamadanatural(lista) que reciba una lista de 
# numeros desordenados y  produzca  una  lista  de  listas,  
# donde  cada  sublista  mantiene  el  orden  natural de la lista original.
# Es decir, se van a tener sublistas que mantienen el orden de 
# suscomponentes, pero que terminan si el siguiente n ́umero 
# en la lista original es menor al actual.

def natural(lista):
    if isinstance(lista,list):
        listaaimprimir=naturalaux(lista,1)
    print(listaaimprimir)


def naturalaux(lista,i):
    if len(lista) > i:
        if lista[i-1] > lista[i]:
            nuevalista=lista[0:i]
            del lista[0:i]
            i=1
            return [nuevalista] + naturalaux(lista,i)
        else:
            i=i+1
            return naturalaux(lista,i)
    else: return [lista]
listanatural=[3,4,5,1,2,3,4,7,3,2,1,6,7,9,0,10,32]

# natural(listanatural)

# Realizar una matriz
#7 Escriba una funci ́on recursivaborde(matriz) que reciba una matriz
#  y genere una lista con los elementos de la matriz que conforman su borde.
matriz=[[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,15],[16,17,18,19,20]]

# for i in matriz:
    # for j in i :
        # print(j, end=" ")
    # print(" ")

def superiores(matriz):
    superior = []
    inferior = []
    for i in matriz[0]:
        superior.append(i)
    for i in matriz[-1]:
        inferior.append(i)
    return superior + inferior

def laterales(matriz):
    if len(matriz)>2 :
        borde_izquierdo= matriz[1][0]
        borde_derecho= matriz[1][-1]
        del matriz[1]
        return [borde_izquierdo]+[borde_derecho]+laterales(matriz)
    else:
        return []

# def borde(matriz):
    # lista_borde=(superiores(matriz)+laterales(matriz))
    # print(lista_borde)
# borde(matriz)

# 8 Escriba una funci ́on recursivadivida(dig, num) que reciba un d ́ıgito 
# y un n ́umero enteroy obtenga dos n ́umeros, el primero compuesto por los 
# dıgitos mayores o iguales al d ́ıgitodado y el segundo compuesto por 
# los d ́ıgitos menores al d ́ıgito dado.

def mayores_menores(num,dig):
    if isinstance(num,int) and dig in range(0,10) :
        return mayores(num,dig,0) , menores(num,dig,0)
    else:
        return "ERROR"

def mayores(num,dig,potencia):
    if num == 0 :
        return 0
    else:
        digito = num%10
        if digito>= dig :
            return digito*10**potencia + mayores(num//10,dig,potencia+1)
        else:
            return mayores(num//10, dig,potencia)

def menores(num,dig,potencia):
    if num == 0 :
        return 0
    else:
        digito = num%10
        if digito< dig :
            return digito*10**potencia + menores(num//10,dig,potencia+1)
        else:
            return menores(num//10, dig,potencia)

# print(mayores_menores(12345678,4))

# 9 Utilice recursividad para implementar la siguiente sumatoria.  
# La funci ́on debe recibircomo par ́ametro un n ́umero que funcione como 
# lımite superior (max_value).

def sumatoria(max_value):
    if isinstance(max_value,int) :
        print(sumatoria_aux(max_value,1))
    else:
        return "ERROR"

def sumatoria_aux(max_value,n):
    if max_value >= n:
        return (2*n+n**(1/2))/(n**3+n**(1/2)) + sumatoria_aux(max_value,(n+1))
    else: 
        return 0
   

print(sumatoria(5))


# 10 Escriba una funci ́on recursivatriangularsuperior(matriz) que debe 
# recibir una matrizde tama ̃nomxmy debe determinar si la matriz es una 
# matriz triangular superior ono.   Una  matriz  es  triangular  superior 
#  si  todos  los  elementos  bajo  su  diagonal  (sinconsiderarla) son 
# ceros.
matriz=[[-1,1,1],[0,1,2],[0,0,3]]
def TriangularSuperior(matriz):
    